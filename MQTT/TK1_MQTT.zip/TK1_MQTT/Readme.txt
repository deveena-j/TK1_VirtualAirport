***********************************************
Submitted by: Gruppe 12

Pritish Kishore Kumar - 2658023
Deveena Jain - 2313494
Siddharth Singh Parihar - 2569976

In order to run the application, kindly follow the below steps:

1) Extract the ZIP file
2) From the project home directory, navigate to /build/classes/java/main folder.
3) Copy this pathname and open in terminal. From this path run 'rmiregistry'
4) Open another terminal instance in the project root directory and execute 'gradle task runServer' to start server
5) Open another terminal instance in the project root directory and execute 'gradle task runBoard' to start the configurable information board.
6) Open another terminal instance in the project root directory and execute 'gradle task runClient' to start the client GUI used to add/edit/delete flights

