package com.tk1rest;

import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.ProtocolException;
import java.net.MalformedURLException;
import java.util.ArrayList;

public class selectSeat extends JFrame{

    private static JPanel contentPane;

    private static int rows_local = 0;
    private static int columns_local = 0;
    private static String preserveUserName = "";


    String reserveURL ="";
    ArrayList<String> opValue = new ArrayList<String>();



    public selectSeat(String username, int rows, int columns) {

        rows_local = rows;
        columns_local = columns;
        preserveUserName = username;

        setTitle("Dashboard - " + username);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 500, 600);
        contentPane = new JPanel(new GridLayout(rows_local, columns_local));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
    }

    public void doSeatSelection(String day, String fl, String cl, int price) {


        for (int row = 0; row < rows_local; row++) {
            for (int column = 0; column < columns_local; column++) {
                final JToggleButton button = new JToggleButton("€ " + price);
                final int currentRowValue = row;
                final int currentColumnValue = column;
                button.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent actionEvent) {
                        AbstractButton abstractButton = (AbstractButton) actionEvent.getSource();
                        boolean selected = abstractButton.getModel().isSelected();

                        if (selected) {

                            /*String result = button.getText();
                            System.out.println("Seat selection is " + currentRowValue + currentColumnValue );*/
                            try {


                            if (fl.equals("Boeing")) {
                                reserveURL = "http://localhost:8090/reserveBoeing?day=" + day +
                                        "&class=" + cl + "&row=" + currentRowValue + "&column=" + currentColumnValue;
                                System.out.println("Debug Print " + cl + " " + day + " " + currentRowValue + currentColumnValue);
                            } else if (fl.equals("Airbus")) {
                                reserveURL = "http://localhost:8090/reserveAirbus?day=" + day +
                                        "&class=" + cl + "&row=" + currentRowValue + "&column=" + currentColumnValue;
                            } else if (fl.equals("Embraer")) {
                                reserveURL = "http://localhost:8090/reserveEmbraer?day=" + day +
                                        "&class=" + cl + "&row=" + currentRowValue + "&column=" + currentColumnValue;
                            }

                            URL url = new URL(reserveURL);
                            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                            conn.setRequestMethod("GET");

                            if (conn.getResponseCode() != 200) {
                                throw new RuntimeException("Failed : HTTP error code : "
                                        + conn.getResponseCode());
                            }

                            BufferedReader br = new BufferedReader(new InputStreamReader(
                                    (conn.getInputStream())));

                            String output = "";
                            System.out.println("Output from Server .... \n");
                            while ((output = br.readLine()) != null) {
                                opValue.add(output);
                                System.out.println("What about this " + output);
                            }


                            conn.disconnect();

                        } catch (MalformedURLException em) {

                            em.printStackTrace();

                        } catch (IOException ex) {

                            ex.printStackTrace();

                        }

                            System.out.println("What is the final op value " + opValue.get(0));
                            if(opValue.get(0).equals("1")){
                                System.out.println("What is the final op value " + opValue.get(0));
                                //System.out.println("Reserved Successfully");
                                JOptionPane.showMessageDialog(null, "Seat " +
                                        currentRowValue + " " + currentColumnValue+ " reserved successfully");
                            }
                            else{
                                //System.out.println("Seat already reserved");
                                JOptionPane.showMessageDialog(null, "Seat " +
                                        currentRowValue + " " + currentColumnValue + " was already reserved. Try again ");
                                dayFlight mainpg = new dayFlight();
                                mainpg.selectDayFlight(preserveUserName);
                                mainpg.setVisible(true);
                            }

                            dispose();

                        }

                    }
                });
                contentPane.add(button);
            }
        }

    }
}
