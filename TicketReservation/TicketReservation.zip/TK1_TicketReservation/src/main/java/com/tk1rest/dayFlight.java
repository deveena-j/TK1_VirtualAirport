package com.tk1rest;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import javax.swing.SwingConstants;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class dayFlight extends JFrame{

    private JPanel contentPane;
    private JComboBox day;
    private JComboBox flight;
    private JComboBox seatClass;
    private JLabel message;
    private JTextField messageText;
    private JButton btnNewButton;

    String fetchURLRow = "http://localhost:8090/fetchSeatsRow";
    String fetchURLColumn = "http://localhost:8090/fetchSeatsColumn";
    String fetchURLPrice = "http://localhost:8090/fetchSeatPrice";
    String outputRow = "";
    String outputColumn = "";
    String outputPrice = "";
    ArrayList<String> opRowValue= new ArrayList<String>();
    ArrayList<String> opColumnValue = new ArrayList<String>();
    ArrayList<String> opPriceValue = new ArrayList<String>();
    int rows = 0;
    int columns = 0;

    public dayFlight() {}

    public void selectDayFlight(String username) {

        //setting the title and frame data
        setTitle("Dashboard - " + username);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 311, 180);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);

        JLabel userlabel = new JLabel("Select day and flight:");
        userlabel.setFont(new Font("Helvetica", Font.BOLD, 15));
        contentPane.add(userlabel);

        day = new JComboBox();
        day.addItem("Monday");
        day.addItem("Tuesday");
        day.addItem("Wednesday");
        day.addItem("Thursday");
        day.addItem("Friday");
        day.addItem("Saturday");
        day.addItem("Sunday");
        contentPane.add(day);

        //String daySelection = day.getSelectedItem().toString();
        //System.out.println(daySelection + " was selected");

        flight = new JComboBox();
        flight.addItem("Boeing");
        flight.addItem("Airbus");
        flight.addItem("Embraer");
        contentPane.add(flight);

        //String flightSelection = flight.getSelectedItem().toString();
        //System.out.println(flightSelection + " was selected");

        seatClass = new JComboBox();
        seatClass.addItem("UnitedFirst");
        seatClass.addItem("EconomyPlus");
        seatClass.addItem("Economy");
        contentPane.add(seatClass);

        //String classSelection = seatClass.getSelectedItem().toString();
        //System.out.println(flightSelection + " was selected");

        btnNewButton = new JButton("Confirm");
        btnNewButton.setFont(new Font("Helvetica", Font.BOLD, 15));
        btnNewButton.setBounds(10, 50, 90, 70);
        btnNewButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e){

                String daySelection = day.getSelectedItem().toString();
                String flightSelection = flight.getSelectedItem().toString();
                String classSelection = seatClass.getSelectedItem().toString();

                //contacting server for next page

                try{
                    fetchURLRow = fetchURLRow + "?flightSelect=" + flightSelection + "&classSelect=" + classSelection;
                    fetchURLColumn = fetchURLColumn + "?flightSelect=" + flightSelection + "&classSelect=" + classSelection;
                    fetchURLPrice = fetchURLPrice + "?classSelect=" + classSelection;
                    URL url1 = new URL(fetchURLRow);
                    URL url2 = new URL(fetchURLColumn);
                    URL url3 = new URL(fetchURLPrice);
                    HttpURLConnection conn1 = (HttpURLConnection) url1.openConnection();
                    HttpURLConnection conn2 = (HttpURLConnection) url2.openConnection();
                    HttpURLConnection conn3 = (HttpURLConnection) url3.openConnection();

                    conn1.setRequestMethod("GET");
                    //conn.setRequestProperty("Accept", "application/json");

                    if (conn1.getResponseCode() != 200) {
                        throw new RuntimeException("Failed : HTTP error code : "
                                + conn1.getResponseCode());
                    }

                    BufferedReader br1 = new BufferedReader(new InputStreamReader(
                            (conn1.getInputStream())));

                    System.out.println("Output from Server .... \n");
                    while ((outputRow = br1.readLine()) != null) {
                        opRowValue.add(outputRow);
                        System.out.println(outputRow);
                    }


                    conn1.disconnect();


                    conn2.setRequestMethod("GET");
                    //conn.setRequestProperty("Accept", "application/json");

                    if (conn2.getResponseCode() != 200) {
                        throw new RuntimeException("Failed : HTTP error code : "
                                + conn2.getResponseCode());
                    }

                    BufferedReader br2 = new BufferedReader(new InputStreamReader(
                            (conn2.getInputStream())));

                    System.out.println("Output from Server .... \n");
                    while ((outputColumn = br2.readLine()) != null) {
                        opColumnValue.add(outputColumn);
                        System.out.println(outputColumn);
                    }

                    conn2.disconnect();


                    conn3.setRequestMethod("GET");
                    //conn.setRequestProperty("Accept", "application/json");

                    if (conn3.getResponseCode() != 200) {
                        throw new RuntimeException("Failed : HTTP error code : "
                                + conn3.getResponseCode());
                    }

                    BufferedReader br3 = new BufferedReader(new InputStreamReader(
                            (conn3.getInputStream())));

                    System.out.println("Output from Server .... \n");
                    while ((outputPrice = br3.readLine()) != null) {
                        opPriceValue.add(outputPrice);
                        System.out.println(outputPrice);
                    }

                    conn2.disconnect();



                } catch (
                        MalformedURLException em) {

                    em.printStackTrace();

                } catch (
                        IOException ex) {

                    ex.printStackTrace();

                }

                System.out.println(daySelection + " was selected");
                System.out.println(flightSelection + " was selected");
                System.out.println(classSelection + "Was selected");
                selectSeat sn = new selectSeat(username, Integer.parseInt(opRowValue.get(0)), Integer.parseInt(opColumnValue.get(0)));
                //selectSeat sn = new selectSeat(username, 1,2);
                sn.doSeatSelection(daySelection, flightSelection, classSelection, Integer.parseInt(opPriceValue.get(0)));
                sn.setVisible(true);

                dispose();

            }


        });
        contentPane.add(btnNewButton);


    }




}
