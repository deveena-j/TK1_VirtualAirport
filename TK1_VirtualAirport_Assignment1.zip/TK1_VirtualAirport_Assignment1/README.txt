***********************************************
Submitted by:

Pritish Kishore Kumar - 2658023
Deveena Jain - 2313494
Siddharth Singh Parihar - 2569976

In order to run the application, kindly follow the below steps:

1) Extract the ZIP file
2) From the project home directory, navigate to /bin folder.
3) Copy this pathname and open in terminal. From this path run 'rmiregistry'
4) Open a new terminal in the project home and run 'gradle task runServer' (this will launch the object server)
5) Open a new terminal in the project home and run './gradlew runParallelTasks (this will launch two object clients in parallel)

Note: When deleting or editing a flight kindly click on the 'Flight Number' on any row and select 'Edit' or 'Delete'
